// Start EnterExit
var enter = document.getElementById("fullscreen"),
    exit  = document.getElementById("exit"),
    watch = document.getElementById("clock-min-container"),
    resLogo  = document.getElementById("res-logo"),
    resLogo01  = document.getElementById("res-logo01");

// enter.onmouseover = function () {
//     enter.classList.remove("enter-anim");
// }
enter.onmouseover = function () {
    enter.classList.remove("enter-anim");
}
enter.onmouseleave = function () {
    enter.classList.add("enter-anim");
}
enter.onclick = function () {
    document.documentElement.requestFullscreen();
    enter.onmouseleave = function () {
        enter.classList.remove("enter-anim");
    }
    enter.classList.remove("enter-anim");
    enter.style.display = "none";
    exit.style.display  = "block";
    setTimeout(function() {
        watch.style.color = "rgb(30, 162, 216, .8)";
        watch.style.backgroundColor = "rgb(30, 162, 216, .2)";
        watch.classList.add("watchStyle");
    }, 1000);
}
exit.onclick = function () {
    document.exitFullscreen();
    watch.classList.remove("watchStyle");
    exit.style.display  = "none";
    enter.style.display = "block";
    watch.style.color = "rgb(30, 162, 216, .0)";
    watch.style.backgroundColor = "rgb(30, 162, 216, .0)";
}
resLogo.onclick = function () {
    document.documentElement.requestFullscreen();
    resLogo.style.display = "none";
    resLogo01.style.display = "block";
}
resLogo01.onclick = function () {
    document.exitFullscreen();
    resLogo01.style.display = "none";
    resLogo.style.display = "block";
}
// (function xo () {
//     if (document.documentElement.requestFullscreen()) {
//         enter.classList.remove("enter-anim");
//         enter.style.display = "none";
//         exit.style.display  = "block";
//         watch.style.color = "rgb(30, 162, 216, .8)";
//         watch.style.backgroundColor = "rgb(30, 162, 216, .2)";
//     } else if (document.exitFullscreen()) {
//         enter.classList.remove("enter-anim");
//         enter.style.display = "none";
//         exit.style.display  = "block";
//         watch.style.color = "rgb(30, 162, 216, .8)";
//         watch.style.backgroundColor = "rgb(30, 162, 216, .2)";
//     }
// });
// End EnterExit

// Start Clock
var clock = document.getElementById('clock');
function colorfulClock(){
var time = new Date(),
hours = time.getHours(),
minutes = time.getMinutes(),
seconds = time.getSeconds();
if(hours <= 9){
hours = '0' + hours;
}
if(minutes <= 9){
minutes = '0' + minutes;
}
if(seconds <= 9){
seconds = '0' + seconds;
}
if(hours >= 12){
seconds = seconds + ' PM';
}else if(hours < 12){
seconds = seconds + ' AM';
}
if(hours > 12){
hours = hours - 12;
if(hours <= 9){
  hours = '0' + hours;
  }
	}
clock.textContent = hours + ':' + minutes + '.' + seconds;
}
setInterval(colorfulClock , 1000 );
var day = document.getElementById('day'),
    t = new Date(),
    d = t.getDay();
   switch(true){
        case d == 0:
    day.textContent = 'Sunday,';
        break;
        case d == 1:
    day.textContent = 'Monday,';
        break;
        case d == 2:
    day.textContent = 'Tuesday,';
        break;
        case d == 3:
    day.textContent = 'Wednesday,';
        break;
        case d == 4:
    day.textContent = 'Thursday,';
        break;
        case d == 5:
    day.textContent = 'Friday,';
        break;
        case d == 6:
    day.textContent = 'Saturday,';
   }
// End Clock

// Start NavBar
var home = document.getElementById("home"),
    about = document.getElementById("about"),
    edu = document.getElementById("edu"),
    touch = document.getElementById("touch"),
    footer = document.getElementById("footer");
home.onclick = function () {
    home.style.backgroundColor = "rgb(30, 162, 216, .2)";
    home.style.boxShadow = ".2vw .2vw .2vw rgb(30, 162, 216, .8)";
    home.style.padding = ".28vw .5vw .28vw .5vw";
    home.style.color = "rgb(32, 50, 66, .8)";
    home.style.borderRadius = ".4vw";
    about.style.backgroundColor = "transparent";
    about.style.boxShadow = "none";
    about.style.padding = "none";
    about.style.color = "none";
    about.style.borderRadius = "none";
    edu.style.backgroundColor = "transparent";
    edu.style.boxShadow = "none";
    edu.style.padding = "none";
    edu.style.color = "none";
    edu.style.borderRadius = "none";
    touch.style.backgroundColor = "transparent";
    touch.style.boxShadow = "none";
    touch.style.padding = "none";
    touch.style.color = "none";
    touch.style.borderRadius = "none";
    home.onmouseover = function () {
        if (home.style.boxShadow === ".2vw .2vw .2vw rgb(30, 162, 216, .8)") {
            home.style.color = "rgb(31, 50, 65)";
        } else if (home.style.boxShadow === "none") {
            home.style.color = "rgb(30, 162, 216)";
        }
    }
    home.onmouseleave = function () {
        if (home.style.boxShadow === ".2vw .2vw .2vw rgb(30, 162, 216, .8)") {
            home.style.color = "rgb(31, 50, 65)";
        } else if (home.style.boxShadow === "none") {
            home.style.color = "rgb(31, 50, 65)";
        }
    }
}
about.onclick = function () {
    home.style.backgroundColor = "transparent";
    home.style.boxShadow = "none";
    home.style.padding = "none";
    home.style.color = "none";
    home.style.borderRadius = "none";
    about.style.backgroundColor = "rgb(30, 162, 216, .2)";
    about.style.boxShadow = ".2vw .2vw .2vw rgb(30, 162, 216, .8)";
    about.style.padding = ".28vw .5vw .28vw .5vw";
    about.style.color = "rgb(32, 50, 66, .8)";
    about.style.borderRadius = ".4vw";
    edu.style.backgroundColor = "transparent";
    edu.style.boxShadow = "none";
    edu.style.padding = "none";
    edu.style.color = "none";
    edu.style.borderRadius = "none";
    touch.style.backgroundColor = "transparent";
    touch.style.boxShadow = "none";
    touch.style.padding = "none";
    touch.style.color = "none";
    touch.style.borderRadius = "none";
    about.onmouseover = function () {
        if (about.style.boxShadow === ".2vw .2vw .2vw rgb(30, 162, 216, .8)") {
            about.style.color = "rgb(31, 50, 65)";
        } else if (about.style.boxShadow === "none") {
            about.style.color = "rgb(30, 162, 216)";
        }
    }
    about.onmouseleave = function () {
        if (about.style.boxShadow === ".2vw .2vw .2vw rgb(30, 162, 216, .8)") {
            about.style.color = "rgb(31, 50, 65)";
        } else if (about.style.boxShadow === "none") {
            about.style.color = "rgb(31, 50, 65)";
        }
    }
}
edu.onclick = function () {
    home.style.backgroundColor = "transparent";
    home.style.boxShadow = "none";
    home.style.padding = "none";
    home.style.color = "none";
    home.style.borderRadius = "none";
    about.style.backgroundColor = "transparent";
    about.style.boxShadow = "none";
    home.style.padding = "none";
    about.style.color = "none";
    about.style.borderRadius = "none";
    edu.style.backgroundColor = "rgb(30, 162, 216, .2)";
    edu.style.boxShadow = ".2vw .2vw .2vw rgb(30, 162, 216, .8)";
    edu.style.padding = ".28vw .5vw .28vw .5vw";
    edu.style.color = "rgb(32, 50, 66, .8)";
    edu.style.borderRadius = ".4vw";
    touch.style.backgroundColor = "transparent";
    touch.style.boxShadow = "none";
    touch.style.padding = "none";
    touch.style.color = "none";
    touch.style.borderRadius = "none";
    edu.onmouseover = function () {
        if (edu.style.boxShadow === ".2vw .2vw .2vw rgb(30, 162, 216, .8)") {
            edu.style.color = "rgb(31, 50, 65)";
        } else if (edu.style.boxShadow === "none") {
            edu.style.color = "rgb(30, 162, 216)";
        }
    }
    edu.onmouseleave = function () {
        if (edu.style.boxShadow === ".2vw .2vw .2vw rgb(30, 162, 216, .8)") {
            edu.style.color = "rgb(31, 50, 65)";
        } else if (edu.style.boxShadow === "none") {
            edu.style.color = "rgb(31, 50, 65)";
        }
    }
}
touch.onclick = function () {
    home.style.backgroundColor = "transparent";
    home.style.boxShadow = "none";
    home.style.padding = "none";
    home.style.color = "none";
    home.style.borderRadius = "none";
    about.style.backgroundColor = "transparent";
    about.style.boxShadow = "none";
    home.style.padding = "none";
    about.style.color = "none";
    about.style.borderRadius = "none";
    edu.style.backgroundColor = "transparent";
    edu.style.boxShadow = "none";
    edu.style.padding = "none";
    edu.style.color = "none";
    edu.style.borderRadius = "none";
    touch.style.backgroundColor = "rgb(30, 162, 216, .2)";
    touch.style.boxShadow = ".2vw .2vw .2vw rgb(30, 162, 216, .8)";
    touch.style.padding = ".28vw .5vw .28vw .5vw";
    touch.style.color = "rgb(32, 50, 66, .8)";
    touch.style.borderRadius = ".4vw";
    touch.onmouseover = function () {
        if (touch.style.boxShadow === ".2vw .2vw .2vw rgb(30, 162, 216, .8)") {
            touch.style.color = "rgb(31, 50, 65)";
        } else if (touch.style.boxShadow === "none") {
            touch.style.color = "rgb(30, 162, 216)";
        }
    }
    touch.onmouseleave = function () {
        if (touch.style.boxShadow === ".2vw .2vw .2vw rgb(30, 162, 216, .8)") {
            touch.style.color = "rgb(31, 50, 65)";
        } else if (touch.style.boxShadow === "none") {
            touch.style.color = "rgb(31, 50, 65)";
        }
    }
}
// End NavBar

// Start window.onload
var media              = document.getElementById("socialMedia"),
    arrow              = document.getElementById("arrow"),
    arrowBtn           = document.getElementById("arrow-down1"),
    ops                = document.getElementById("ops"),
    logoBox            = document.getElementById("logo-box"),
    resBox             = document.getElementById("res-third-plate-box"),
    loader             = document.getElementById("loader-main");
    nameWriter         = document.getElementById("nameWriter"),
    positionWriter     = document.getElementById("positionWriter"),
    nameTitleContainer = document.getElementById("name-title-container");

window.onload = function () {
    arrow.classList.add("arr-anim");
    arrowBtn.classList.add("arrow-anim");
    arrow.onmouseover = function () {
        arrow.classList.remove("arr-anim");
        arrowBtn.classList.remove("arrow-anim");
    }
        loader.style.opacity = "0";
        loader.style.visibility = "hidden";
        setTimeout(function() {
            document.body.style.overflowY = "visible";
        }, 750);
    setTimeout(function () {
        media.style.right = "0vw";
        media.style.transition = "all .5s ease-in-out";
    }, 2500);
    nameTitleContainer.style.visibility = "visible";
    nameWriter.classList.add("anim-typewriter");
    positionWriter.classList.add("anim-typewriter");
    enter.classList.add("enter-anim");
    ops.style.transform = "translateY(0) scale(1)";
    resLogo.style.transform = "translateY(0)scale(1)";
    logoBox.style.transform = "translateY(0)";
    setTimeout(function () {
        resBox.style.boxShadow = "-.3vw -.3vw .3vw rgb(32, 50, 66)inset";
    }, 8000);
    resBox.style.opacity = "1";
}
// End window.onload

// Start Scroll 
var navBar = document.getElementById("nav-bar"),
    logo   = document.getElementById("logo"),
    logo01   = document.getElementById("logo01"),
    logo02   = document.getElementById("logo02"),
    navNav = document.getElementById("navIconsFirst"),
    html   = document.getElementById("html-level"),
    css    = document.getElementById("css-level"),
    java   = document.getElementById("java-level"),
    es6    = document.getElementById("es6-level"),
    git    = document.getElementById("git-level"),
    res    = document.getElementById("res-level"),
    react  = document.getElementById("react-level"),
    levels = document.getElementsByClassName("levels"),
    relevel = document.getElementById("re-level"),
    english = document.getElementById("english-level"),
    german = document.getElementById("german-level"),
    arabic = document.getElementById("arabic-level"),
    langLevel = document.getElementsByClassName("lang-level"),
    x = document.getElementsByClassName("x"),
    messageIcon = document.getElementById("messageIcon"),
    downloadCv = document.getElementById("download-cv"),
    downloadCertificate = document.getElementById("download-certificate"),
    whatsApp = document.getElementById("whatsApp"),
    email = document.getElementById("email"),
    linkedin = document.getElementById("linkedin"),
    xing = document.getElementById("xing"),
    github = document.getElementById("github"),
    work    = document.getElementById("work"),
    footerDCI = document.getElementById("footer-dci"),
    logos = document.getElementsByClassName("logos"),
    bottomPlate = document.getElementById("bottom-plate"),
    positionsBox = document.getElementById("positions-box"),
    brandsName = document.getElementsByClassName("brands-name"),
    firstBrand = document.getElementById("first-brand"),
    secondBrand = document.getElementById("second-brand"),
    firstSpan = document.getElementsByClassName("first-span"),
    secondSpan = document.getElementsByClassName("second-span"),
    bottomPlateMain = document.getElementById("bottom-plate-main"),
    end = document.getElementById("end"),
    btnA = document.getElementsByClassName("btnA"),
    aboutContainer = document.getElementById("about-container");

window.onscroll = function () {
    if (document.documentElement.scrollTop > (window.innerHeight / 3)) {
        navBar.style.borderBottom = ".3vw solid rgb(30, 162, 216, .5)";
        navBar.style.transition = "all .5s ease-in-out";
    } else if(document.documentElement.scrollTop < (window.innerHeight / 3)) {
        setTimeout(function () {
            navNav.style.width = "fit-content";
        }, 200);
        navBar.style.borderBottom = "0px solid transparent";
        navBar.style.transition = "all 1s ease-in-out";
    }
    if (document.documentElement.scrollTop > window.innerHeight) {
        logo01.style.color = "rgb(30, 162, 216)";
        logo01.style.textShadow =".2vw .3vw .2vw rgb(30, 162, 216, .5)";
        logo01.style.transition = "all .8s ease-in-out";
    } else if (document.documentElement.scrollTop < window.innerHeight) {
        logo01.style.color = "rgb(30, 162, 216, 0)";
        logo01.style.textShadow =".2vw .3vw .2vw rgb(30, 162, 216, 0)";
        logo01.style.transition = "all 1s ease-in-out";
    }
    if (document.documentElement.scrollTop < window.innerHeight && document.documentElement.scrollTop > 1) {
        home.style.backgroundColor = "rgb(30, 162, 216, .2)";
        home.style.boxShadow = ".2vw .2vw .2vw rgb(30, 162, 216, .8)";
        home.style.padding = ".28vw .5vw .28vw .5vw";
        home.style.color = "rgb(32, 50, 66, .8)";
        home.style.borderRadius = ".4vw";
        home.style.transition = "all .5s ease-in-out";
        about.style.backgroundColor = "transparent";
        about.style.boxShadow = "none";
        about.style.padding = "none";
        about.style.color = "none";
        about.style.borderRadius = "none";
        edu.style.backgroundColor = "transparent";
        edu.style.boxShadow = "none";
        edu.style.padding = "none";
                edu.style.color = "none";
        edu.style.borderRadius = "none";
        touch.style.backgroundColor = "transparent";
        touch.style.boxShadow = "none";
        touch.style.padding = "none";
        touch.style.color = "none";
        touch.style.borderRadius = "none";
        setTimeout(function () {
            navNav.style.width = "3.7vw";
        }, 200);
        setTimeout(function () {
            html.style.width = "90%";
            html.style.transition = "all .7s ease-in-out";
            css.style.width = "85%";
            css.style.transition = "all .7s ease-in-out";
            java.style.width = "80%";
            java.style.transition = "all .7s ease-in-out";
            es6.style.width = "80%";
            es6.style.transition = "all .7s ease-in-out";
            git.style.width = "70%";
            git.style.transition = "all .7s ease-in-out";
            res.style.width = "85%";
            res.style.transition = "all .7s ease-in-out";
            react.style.width = "80%";
            react.style.transition = "all .7s ease-in-out";
            setTimeout(function () {
                relevel.style.display = "block";
                for(i = 0; i < 6; i++){
                    levels[i].style.display = "block";
                }
            }, 500);
        }, 250);
        home.onmouseover = function () {
            if (home.style.boxShadow === ".2vw .2vw .2vw rgb(30, 162, 216, .8)") {
                home.style.color = "rgb(31, 50, 65)";
            } else if (home.style.boxShadow === "none") {
                home.style.color = "rgb(30, 162, 216)";
            }
        }
        home.onmouseleave = function () {
            if (home.style.boxShadow === ".2vw .2vw .2vw rgb(30, 162, 216, .8)") {
                home.style.color = "rgb(31, 50, 65)";
            } else if (home.style.boxShadow === "none") {
                home.style.color = "rgb(31, 50, 65)";
            }
        }
    } else if (document.documentElement.scrollTop > window.innerHeight && document.documentElement.scrollTop < (window.innerHeight * 2)) {
        // setTimeout(function () {
        //     aboutContainer.style.backgroundColor = "rgb(31, 50, 65, .1)";
        // }, 500);
        // setTimeout(function () {
        //     aboutContainer.style.boxShadow = "-.2vw -.2vw .2vw rgb(30, 162, 216, .3)inset";
        // }, 1000);
        navBar.classList.add("navBarStyle");
        // navBar.onmouseover = function () {
        //     navBar.classList.remove("navBarStyle");
        // }
        // edu.onmouseover = function () {
        //     navBar.classList.remove("navBarStyle");
        // }
        // touch.onmouseover = function () {
        //     navBar.classList.remove("navBarStyle");
        // }
        // footer.onmouseover = function () {
        //     navBar.classList.remove("navBarStyle");
        // }
        setTimeout(function () {
            navNav.style.width = "3.7vw";
        }, 200);
        home.style.backgroundColor = "transparent";
        home.style.boxShadow = "none";
        home.style.padding = "none";
        home.style.color = "none";
        home.style.borderRadius = "none";
        home.style.transition = "all .3s ease-in-out";
        about.style.backgroundColor = "rgb(30, 162, 216, .2)";
        about.style.boxShadow = ".2vw .2vw .2vw rgb(30, 162, 216, .8)";
        about.style.padding = ".28vw .5vw .28vw .5vw";
        about.style.color = "rgb(32, 50, 66, .8)";
        about.style.borderRadius = ".4vw";
        about.style.transition = "all .3s ease-in-out";
        edu.style.backgroundColor = "transparent";
        edu.style.boxShadow = "none";
        edu.style.padding = "none";
        edu.style.color = "none";
        edu.style.borderRadius = "none";
        touch.style.backgroundColor = "transparent";
        touch.style.boxShadow = "none";
        touch.style.padding = "none";
        touch.style.color = "none";
        touch.style.borderRadius = "none";
        about.onmouseover = function () {
            if (about.style.boxShadow === ".2vw .2vw .2vw rgb(30, 162, 216, .8)") {
                about.style.color = "rgb(31, 50, 65)";
            } else if (about.style.boxShadow === "none") {
                about.style.color = "rgb(30, 162, 216)";
            }
        }
        about.onmouseleave = function () {
            if (about.style.boxShadow === ".2vw .2vw .2vw rgb(30, 162, 216, .8)") {
                about.style.color = "rgb(31, 50, 65)";
            } else if (about.style.boxShadow === "none") {
                about.style.color = "rgb(31, 50, 65)";
            }
        }
    } else if(document.documentElement.scrollTop > (window.innerHeight * 2) && document.documentElement.scrollTop < (window.innerHeight * 3)) {
        setTimeout(function () {
            navNav.style.width = "fit-content";
        }, 200);
        home.style.backgroundColor = "transparent";
        home.style.boxShadow = "none";
        home.style.padding = "none";
        home.style.color = "none";
        home.style.borderRadius = "none";
        about.style.backgroundColor = "transparent";
        about.style.boxShadow = "none";
        home.style.padding = "none";
        about.style.color = "none";
        about.style.transition = "all .3s ease-in-out";
        about.style.borderRadius = "none";
        edu.style.backgroundColor = "rgb(30, 162, 216, .2)";
        edu.style.boxShadow = ".2vw .2vw .2vw rgb(30, 162, 216, .8)";
        edu.style.padding = ".28vw .5vw .28vw .5vw";
        edu.style.color = "rgb(32, 50, 66, .8)";
        edu.style.borderRadius = ".4vw";
        edu.style.transition = "all .3s ease-in-out";
        touch.style.backgroundColor = "transparent";
        touch.style.boxShadow = "none";
        touch.style.padding = "none";
        touch.style.color = "none";
        touch.style.borderRadius = "none";
        media.style.transform = "translateY(0%)";

        whatsApp.onmouseover = function () {
            whatsApp.style.color = "#1ea2d8";
            whatsApp.onmouseleave = function () {
                whatsApp.style.color = "#1f3241";
            }
        }
        email.onmouseover = function () {
            email.style.color = "#1ea2d8";
            email.onmouseleave = function () {
                email.style.color = "#1f3241";
            }
        }
        linkedin.onmouseover = function () {
            linkedin.style.color = "#1ea2d8";
            linkedin.onmouseleave = function () {
                linkedin.style.color = "#1f3241";
            }
        }
        xing.onmouseover = function () {
            xing.style.color = "#1ea2d8";
            xing.onmouseleave = function () {
                xing.style.color = "#1f3241";
            }
        }
        github.onmouseover = function () {
            github.style.color = "#1ea2d8";
            github.onmouseleave = function () {
                github.style.color = "#1f3241";
            }
        }

            english.style.width = "90%";
            english.style.transition = "all .7s ease-in-out";
            german.style.width = "50%";
            german.style.transition = "all .7s ease-in-out";
            arabic.style.width = "100%";
            arabic.style.transition = "all .7s ease-in-out";
            for(i = 0; i < 2; i++) {
                x[i].style.transform = "scale(1)rotateY(360deg)rotateY(360deg)";
                x[i].style.transition = "all 1.5s ease-in-out";
            }
            setTimeout(function () {
                for(i = 0; i < 3; i++){
                    langLevel[i].style.display = "block";
                }
            }, 500);
        edu.onmouseover = function () {
            if (edu.style.boxShadow === ".2vw .2vw .2vw rgb(30, 162, 216, .8)") {
                edu.style.color = "rgb(31, 50, 65)";
            } else if (edu.style.boxShadow === "none") {
                edu.style.color = "rgb(30, 162, 216)";
            }
        }
        edu.onmouseleave = function () {
            if (edu.style.boxShadow === ".2vw .2vw .2vw rgb(30, 162, 216, .8)") {
                edu.style.color = "rgb(31, 50, 65)";
            } else if (edu.style.boxShadow === "none") {
                edu.style.color = "rgb(31, 50, 65)";
            }
        }
    } else if(document.documentElement.scrollTop > (window.innerHeight * 3) && document.documentElement.scrollTop < (window.innerHeight * 4)) {
        home.style.backgroundColor = "transparent";
        home.style.boxShadow = "none";
        home.style.padding = "none";
        home.style.color = "none";
        home.style.borderRadius = "none";
        about.style.backgroundColor = "transparent";
        about.style.boxShadow = "none";
        about.style.padding = "none";
        about.style.color = "none";
        about.style.borderRadius = "none";
        footer.style.backgroundColor = "transparent";
        footer.style.boxShadow = "none";
        footer.style.padding = "none";
        footer.style.color = "none";
        footer.style.borderRadius = "none";
        edu.style.backgroundColor = "transparent";
        edu.style.boxShadow = "none";
        edu.style.padding = "none";
        edu.style.color = "none";
        edu.style.borderRadius = "none";
        edu.style.transition = "all .3s ease-in-out";
        touch.style.backgroundColor = "rgb(30, 162, 216, .2)";
        touch.style.boxShadow = ".2vw .2vw .2vw rgb(30, 162, 216, .8)";
        touch.style.padding = ".28vw .5vw .28vw .5vw";
        touch.style.color = "rgb(32, 50, 66, .8)";
        touch.style.borderRadius = ".4vw";
        touch.style.transition = "all .3s ease-in-out";
        media.style.transform = "translateY(38%)";
        work.style.transform = "translateX(0) scale(1)";
        for (i = 0; i < 3; i++ ) {
            logos[i].style.transform = "scale(1)rotateY(360deg)rotateY(360deg)";
            brandsName[i].style.display = "block";
            firstBrand.classList.add("anim-typewriter04");
            secondBrand.classList.add("anim-typewriter03");
        }
        setTimeout(function () {
            bottomPlateMain.style.backgroundImage = "linear-gradient( rgb(30, 162, 216, .8) 0%, rgb(32, 50, 66, .0) 100%)";
        }, 1500);
        setTimeout(function () {
            bottomPlate.style.borderTopColor = "rgb(32, 50, 66)";
            end.style.opacity = "1";
        }, 2000);
        setTimeout(function() {
            // positionsBox.style.opacity = "1";
            for (i = 0; i < 2; i++ ) {
                firstSpan[i].style.opacity = "1";
            }
        }, 2750);
        setTimeout(function() {
            // positionsBox.style.opacity = "1";
            for (i = 0; i < 2; i++ ) {
                secondSpan[i].style.opacity = "1";
            }
        }, 3250);
        whatsApp.onmouseover = function () {
            whatsApp.style.color = "#f0f0f0";
            whatsApp.onmouseleave = function () {
                whatsApp.style.color = "#1f3241";
            }
        }
        email.onmouseover = function () {
            email.style.color = "#f0f0f0";
            email.onmouseleave = function () {
                email.style.color = "#1f3241";
            }
        }
        linkedin.onmouseover = function () {
            linkedin.style.color = "#f0f0f0";
            linkedin.onmouseleave = function () {
                linkedin.style.color = "#1f3241";
            }
        }
        xing.onmouseover = function () {
            xing.style.color = "#f0f0f0";
            xing.onmouseleave = function () {
                xing.style.color = "#1f3241";
            }
        }
        github.onmouseover = function () {
            github.style.color = "#f0f0f0";
            github.onmouseleave = function () {
                github.style.color = "#1f3241";
            }
        }

        touch.onmouseover = function () {
            if (touch.style.boxShadow === ".2vw .2vw .2vw rgb(30, 162, 216, .8)") {
                touch.style.color = "rgb(31, 50, 65)";
            } else if (touch.style.boxShadow === "none") {
                touch.style.color = "rgb(30, 162, 216)";
            }
        }
        touch.onmouseleave = function () {
            if (touch.style.boxShadow === ".2vw .2vw .2vw rgb(30, 162, 216, .8)") {
                touch.style.color = "rgb(31, 50, 65)";
            } else if (touch.style.boxShadow === "none") {
                touch.style.color = "rgb(31, 50, 65)";
            }
        }
    } else if(document.documentElement.scrollTop > (window.innerHeight * 4) && document.documentElement.scrollTop < (window.innerHeight * 5)) {
        home.style.backgroundColor = "transparent";
        home.style.boxShadow = "none";
        home.style.padding = "none";
        home.style.color = "none";
        home.style.borderRadius = "none";
        about.style.backgroundColor = "transparent";
        about.style.boxShadow = "none";
        home.style.padding = "none";
        about.style.color = "none";
        about.style.borderRadius = "none";
        edu.style.backgroundColor = "transparent";
        edu.style.boxShadow = "none";
        edu.style.padding = "none";
        edu.style.color = "none";
        edu.style.borderRadius = "none";
        edu.style.transition = "all .3s ease-in-out";
        touch.style.backgroundColor = "transparent";
        touch.style.boxShadow = "none";
        touch.style.padding = "none";
        touch.style.color = "none";
        touch.style.borderRadius = "none";
        footer.style.backgroundColor = "rgb(30, 162, 216, .2)";
        footer.style.boxShadow = ".2vw .2vw .2vw rgb(30, 162, 216, .8)";
        footer.style.padding = ".28vw .5vw .28vw .5vw";
        footer.style.color = "rgb(32, 50, 66, .8)";
        footer.style.borderRadius = ".4vw";
        footer.style.transition = "all .3s ease-in-out";
        media.style.transform = "translateY(0%)";
        messageIcon.style.transform = "translateY(0vw) scale(1)";
        messageIcon.style.transition = "all .7s ease-in-out";
        downloadCv.style.transform = "translateY(1.5vw) scale(1)";
        downloadCv.style.transition = "all .7s ease-in-out";
        downloadCertificate.style.transform = "translateY(0vw) scale(1)";
        downloadCv.classList.add("btnStyle");
        for(i = 0; i < 1; i++) {
            btnA[i].classList.add("btnAStyle");
        }
        setTimeout(function () {
        downloadCertificate.classList.add("btnStyle");
        for(i = 1; i < 2; i++) {
            btnA[i].classList.add("btnAStyle");
        }
        }, 1000);
        downloadCertificate.style.transition = "all .7s ease-in-out";
        footerDCI.style.transform = "scale(1)";
        whatsApp.onmouseover = function () {
            whatsApp.style.color = "#1ea2d8";
            whatsApp.onmouseleave = function () {
                whatsApp.style.color = "#1f3241";
            }
        }
        email.onmouseover = function () {
            email.style.color = "#1ea2d8";
            email.onmouseleave = function () {
                email.style.color = "#1f3241";
            }
        }
        linkedin.onmouseover = function () {
            linkedin.style.color = "#1ea2d8";
            linkedin.onmouseleave = function () {
                linkedin.style.color = "#1f3241";
            }
        }
        xing.onmouseover = function () {
            xing.style.color = "#1ea2d8";
            xing.onmouseleave = function () {
                xing.style.color = "#1f3241";
            }
        }
        github.onmouseover = function () {
            github.style.color = "#1ea2d8";
            github.onmouseleave = function () {
                github.style.color = "#1f3241";
            }
        }

        footer.onmouseover = function () {
            if (footer.style.boxShadow === ".2vw .2vw .2vw rgb(30, 162, 216, .8)") {
                footer.style.color = "rgb(31, 50, 65)";
            } else if (footer.style.boxShadow === "none") {
                footer.style.color = "rgb(30, 162, 216)";
            }
        }
        footer.onmouseleave = function () {
            if (footer.style.boxShadow === ".2vw .2vw .2vw rgb(30, 162, 216, .8)") {
                footer.style.color = "rgb(31, 50, 65)";
            } else if (footer.style.boxShadow === "none") {
                footer.style.color = "rgb(31, 50, 65)";
            }
        }
    } else if (document.documentElement.scrollTop == 0) {
        home.style.backgroundColor = "transparent";
        home.style.boxShadow = "none";
        home.style.padding = "none";
        home.style.color = "none";
        home.style.borderRadius = "none";
        about.style.backgroundColor = "transparent";
        about.style.boxShadow = "none";
        home.style.padding = "none";
        about.style.color = "none";
        about.style.borderRadius = "none";
        edu.style.backgroundColor = "transparent";
        edu.style.boxShadow = "none";
        edu.style.padding = "none";
        edu.style.color = "none";
        edu.style.borderRadius = "none";
        touch.style.backgroundColor = "transparent";
        touch.style.boxShadow = "none";
        touch.style.padding = "none";
        touch.style.color = "none";
        touch.style.borderRadius = "none";
    }
    console.log(window.innerHeight);
    console.log(document.documentElement.scrollTop)
}
// End Window.onscroll

// Start Nav Bar Moving
var arrowDiv = document.getElementById("intro-arrow"),
    inTouch  = document.getElementById("inTouch"),
    inTouch02 = document.getElementById("inTouch02"),
    inTouch03 = document.getElementById("inTouch03"),
    inTouch04 = document.getElementById("inTouch04");

logo.onclick = function () {
    document.documentElement.scrollTop = window.innerHeight * 5 + 1;
}
logo01.onclick = function () {
    document.documentElement.scrollTop = 0;
}
logo02.onclick = function () {
    document.documentElement.scrollTop = 0;
}
home.onclick = function () {
    document.documentElement.scrollTop = 1;
}
arrowDiv.onclick = function () {
    document.documentElement.scrollTop = window.innerHeight + 1;
}
about.onclick = function () {
    document.documentElement.scrollTop = window.innerHeight + 1;
}
edu.onclick = function () {
    document.documentElement.scrollTop = window.innerHeight * 2 + 1;
}
inTouch02.onclick = function () {
    document.documentElement.scrollTop = window.innerHeight * 2 + 1;
}
inTouch03.onclick = function () {
    document.documentElement.scrollTop = window.innerHeight * 3 + 1;
}
inTouch04.onclick = function () {
    document.documentElement.scrollTop = window.innerHeight * 3 + 1;
}
touch.onclick = function () {
    document.documentElement.scrollTop = window.innerHeight * 3 + 1;
}
inTouch.onclick = function () {
    document.documentElement.scrollTop = window.innerHeight * 5 + 1;
}
footer.onclick = function () {
    document.documentElement.scrollTop = window.innerHeight * 5 + 1;
}

var nameInput = document.getElementById("nameInput"),
    nameEffect = document.getElementsByClassName("nameEffect"),
    emailInput = document.getElementById("emailInput"),
    textareaInput = document.getElementById("textareaInput"),
    subjectInput = document.getElementById("subjectInput"),
    fifthPlate = document.getElementById("fifth-plate"),
    send = document.getElementById("send"),
    reset = document.getElementById("reset");

nameInput.onclick = function () {
    nameInput.classList.remove("nameEffect");
    nameInput.style.backgroundColor = "rgb(30, 162, 216, .5)";
    emailInput.style.backgroundColor = "rgb(30, 162, 216, .3)";
    textareaInput.style.backgroundColor = "rgb(30, 162, 216, .3)";
    subjectInput.style.backgroundColor = "rgb(30, 162, 216, .3)";
}
emailInput.onclick = function () {
    emailInput.style.backgroundColor = "rgb(30, 162, 216, .5)";
    nameInput.style.backgroundColor = "rgb(30, 162, 216, .3)";
    textareaInput.style.backgroundColor = "rgb(30, 162, 216, .3)";
    subjectInput.style.backgroundColor = "rgb(30, 162, 216, .3)";
}
subjectInput.onclick = function () {
    subjectInput.style.backgroundColor = "rgb(30, 162, 216, .5)";
    textareaInput.style.backgroundColor = "rgb(30, 162, 216, .3)";
    nameInput.style.backgroundColor = "rgb(30, 162, 216, .3)";
    emailInput.style.backgroundColor = "rgb(30, 162, 216, .3)";
}
textareaInput.onclick = function () {
    textareaInput.style.backgroundColor = "rgb(30, 162, 216, .5)";
    nameInput.style.backgroundColor = "rgb(30, 162, 216, .3)";
    emailInput.style.backgroundColor = "rgb(30, 162, 216, .3)";
    subjectInput.style.backgroundColor = "rgb(30, 162, 216, .3)";
}
send.onclick = function () {
    textareaInput.style.backgroundColor = "rgb(30, 162, 216, .3)";
    nameInput.style.backgroundColor = "rgb(30, 162, 216, .3)";
    emailInput.style.backgroundColor = "rgb(30, 162, 216, .3)";
    subjectInput.style.backgroundColor = "rgb(30, 162, 216, .3)";
}
reset.onclick = function () {
    textareaInput.style.backgroundColor = "rgb(30, 162, 216, .3)";
    nameInput.style.backgroundColor = "rgb(30, 162, 216, .3)";
    emailInput.style.backgroundColor = "rgb(30, 162, 216, .3)";
    subjectInput.style.backgroundColor = "rgb(30, 162, 216, .3)";
}
